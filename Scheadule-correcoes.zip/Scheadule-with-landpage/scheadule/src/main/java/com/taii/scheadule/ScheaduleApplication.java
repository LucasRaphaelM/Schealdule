package com.taii.scheadule;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ScheaduleApplication {

    public static void main(String[] args) {
        SpringApplication.run(ScheaduleApplication.class, args);
    }
}