package com.taii.scheadule.controllers;
import org.springframework.web.bind.annotation.*;



@RestController
@RequestMapping("/clientes")
public class ClienteController {


}
