package com.taii.scheadule.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import com.taii.scheadule.model.Administradores;
import com.taii.scheadule.model.Agendamento;
import com.taii.scheadule.model.Cliente;
import com.taii.scheadule.model.Medicos;
import com.taii.scheadule.respository.AdministradoresRepo;
import com.taii.scheadule.respository.AgendamentoRepo;
import com.taii.scheadule.respository.ClienteRepo;
import com.taii.scheadule.respository.MedicosRepo;





@Controller
public class HomeController {
    
    @Autowired
    AdministradoresRepo administradoresRepo;

    @Autowired
    AgendamentoRepo agendamentoRepo;

    @Autowired
    ClienteRepo clienteRepo;

    @Autowired
    MedicosRepo medicosRepo;

    @PostMapping("/logar") //confere o login e permite ou não o acesso
    public String getUser(Model model, Administradores administradores){  
      Administradores administradoresLogados = administradoresRepo.loginValidation (administradores.getEmail(), administradores.getSenha());
    
      if(administradoresLogados != null){
            return "redirect:/inicio";
      }
          model.addAttribute("erro", "Usuário ou senha incorreto.");
          return "/home/login";

    }

    @GetMapping("/") //isso aqui define a rota para onde vou ir
    public String landpage(){
        return "home/landpage";

    }

    @GetMapping("/medicos") //isso aqui define a rota para onde vou ir
    public String medicos(){
        return "home/medico";


    }

    @GetMapping("/inicio")
    public String inicio(Model model) {
        
        List<Agendamento> agendamentos = agendamentoRepo.findAll();
        model.addAttribute("agendamentos", agendamentos);

        List<Medicos> medicos = medicosRepo.findAll();
        model.addAttribute("medicos", medicos);

        return "home/pagina";


    }
    @GetMapping("/login")
    public String index(Model model) {
        return "home/login";
    }
    
    // @GetMapping("/loginbt")
    // public String loginbt() {
    //     return "home/loginbt";
    // }

    @PostMapping("/medico/cadastrar")
    public String cadastrarMedico(Medicos medico){
        medicosRepo.save(medico);

        return "redirect:/inicio";
    }

    @PostMapping("/agendar")
    public String agendar(Cliente cliente,String data, String horario, String motivo, String idmedico) {
        System.out.println("=========================="+cliente.getNome()+cliente.getCpf());
        System.out.println("==================="+idmedico);
        clienteRepo.save(cliente);
        Agendamento agendamento = new Agendamento();
        agendamento.setCliente(cliente);
        Medicos medico = medicosRepo.findById(Integer.valueOf(idmedico)).get();
        agendamento.setId_medico(medico);
        agendamento.setMotivo_consulta(motivo);
        agendamentoRepo.save(agendamento);
        return "redirect:/inicio";
    }
}