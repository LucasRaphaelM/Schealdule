package com.taii.scheadule.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="tbl_Administradores")
public class Administradores {

@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

@Column(name = "email", nullable = false, length = 255, unique = true)
    private String email;


@Column(name = "senha", nullable = false, length = 255)
    private String senha;

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}