package com.taii.scheadule.model;

import java.util.Calendar;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;



@Entity
@Table(name="tbl_agendamento")
public class Agendamento {
    public static final int STATUS_NAO_CONFIRMADO = 0;
    public static final int STATUS_CONFIRMADO = 1;
    public static final int STATUS_DESISTIU = 2;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }

    @ManyToOne
    @JoinColumn(name="id_cliente")
    private Cliente cliente;

    @ManyToOne
    @JoinColumn(name="id_medico")
    private Medicos medico;

    private String motivo_consulta;
    private Calendar data_consulta;
    private int status;
    
    public Cliente getCliente() {
        return cliente;
    }
    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }
    public Medicos getId_medico() {
        return medico;
    }
    public void setId_medico(Medicos medico) {
        this.medico = medico;
    }
    public String getMotivo_consulta() {
        return motivo_consulta;
    }
    public void setMotivo_consulta(String motivo_consulta) {
        this.motivo_consulta = motivo_consulta;
    }
    public Calendar getData_consulta() {
        return data_consulta;
    }
    public void setData_consulta(Calendar data_consulta) {
        this.data_consulta = data_consulta;
    }
    public int getStatus() {
        return status;
    }
    public void setStatus(int status) {
        this.status = status;
    } 
}
