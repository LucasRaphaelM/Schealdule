package com.taii.scheadule.respository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.taii.scheadule.model.Administradores;



public interface AdministradoresRepo extends JpaRepository <Administradores, Integer> {

    @Query(value = "SELECT*FROM tbl_administradores WHERE email = :email AND senha = MD5(:senha)", nativeQuery = true)
    public Administradores loginValidation(String email, String senha);


}
