package com.taii.scheadule.respository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.taii.scheadule.model.Agendamento;

public interface AgendamentoRepo extends JpaRepository <Agendamento, Integer> {
    
}
