package com.taii.scheadule.respository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.taii.scheadule.model.Cliente;

@Repository
public interface ClienteRepo extends JpaRepository<Cliente, Integer> {
    
}
