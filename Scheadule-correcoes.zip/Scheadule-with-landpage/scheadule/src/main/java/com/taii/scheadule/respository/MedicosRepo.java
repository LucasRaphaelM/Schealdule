package com.taii.scheadule.respository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.taii.scheadule.model.Medicos;

public interface MedicosRepo extends JpaRepository <Medicos,Integer>{
    
}
