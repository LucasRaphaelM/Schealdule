package com.taii.scheadule;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScheaduleApplicationTests {

	@Test
	void contextLoads() {
	}

}
